# Élan Déménagement — site + back-office

## Structure

```
frontend/index.html     → le site public (à héberger sur Cloudflare Pages, ou n'importe quel hébergeur statique)
backend/                → l'API (Cloudflare Worker + base D1)
  wrangler.toml
  schema.sql
  src/worker.js
```

## 1. Emails : Resend, pas Formspree

**Formspree n'est pas adapté ici** : c'est un service pensé pour un simple `<form action="...">` HTML qui redirige un email à toi, avec un plan gratuit limité à **50 soumissions/mois**, et pas de logique conditionnelle (mode transparent vs masqué, email différent au client et au pro, calcul du prix côté serveur). Comme on a déjà un vrai backend (le Worker), autant appeler directement une API d'envoi d'email depuis celui-ci.

**Recommandation : [Resend](https://resend.com)**
- Gratuit : 3 000 emails/mois, 100/jour — largement suffisant pour démarrer.
- API très simple (un seul appel `fetch` depuis le Worker, déjà écrit dans `worker.js`).
- Fonctionne très bien avec Cloudflare (tu vas juste ajouter des enregistrements DNS chez Cloudflare pour vérifier ton domaine).

**Étapes Resend :**
1. Crée un compte sur resend.com (gratuit).
2. Ajoute ton domaine (ex. `elan-demenagement-demo.fr`) dans Resend → il te donne des enregistrements DNS (SPF, DKIM) à ajouter.
3. Comme ton domaine est déjà sur Cloudflare, ajoute ces enregistrements dans Cloudflare DNS (copier-coller, ça prend 5 min). C'est obligatoire — n'importe quel service d'email (Resend, SendGrid, Mailgun...) demande ça pour éviter le spam, ce n'est pas une contrainte propre à Resend.
4. Une fois le domaine vérifié, crée une clé API dans Resend → tu l'utiliseras comme secret `RESEND_API_KEY` (étape 3 ci-dessous).
5. Tant que le domaine n'est pas vérifié, Resend te laisse envoyer uniquement à l'adresse email de ton propre compte Resend — utile pour tester avant de brancher un vrai domaine.

## 2. Installer les outils Cloudflare

```bash
npm install -g wrangler
wrangler login
```

## 3. Créer la base de données D1

```bash
cd backend
wrangler d1 create elan-demenagement-db
```

Copie le `database_id` retourné dans `wrangler.toml` (remplace `COLLE_ICI_TON_DATABASE_ID`).

Puis crée les tables :

```bash
wrangler d1 execute elan-demenagement-db --remote --file=./schema.sql
```

## 4. Définir les secrets (jamais dans le code)

```bash
wrangler secret put ADMIN_PASSWORD
# → tape le code d'accès de l'espace pro, ex: un mot de passe solide

wrangler secret put ADMIN_TOKEN_SECRET
# → colle une longue chaîne aléatoire (ex: générée avec `openssl rand -hex 32`)

wrangler secret put RESEND_API_KEY
# → colle la clé API obtenue sur resend.com
```

## 5. Déployer le Worker

```bash
wrangler deploy
```

Wrangler affiche une URL du type `https://elan-demenagement-api.<ton-compte>.workers.dev`.

## 6. Brancher le site public sur l'API

Ouvre `frontend/index.html`, cherche la ligne :

```js
const API_BASE = 'https://elan-demenagement-api.TON-SOUS-DOMAINE.workers.dev';
```

Remplace par l'URL obtenue à l'étape 5 (ou par ton domaine personnalisé si tu en configures un pour le Worker dans Cloudflare).

## 7. Configurer les emails de contact dans l'espace pro

Une fois le site en ligne :
1. Ouvre le site → lien "Espace professionnel" en bas de page → connecte-toi avec le mot de passe défini à l'étape 4.
2. Onglet "Tarification" → renseigne :
   - **Email du déménageur** : où recevoir chaque demande de devis (toujours envoyé, quel que soit le mode).
   - **Email d'expédition** : doit être une adresse sur le domaine vérifié dans Resend (ex. `devis@elan-demenagement-demo.fr`).
3. Choisis le mode (transparent ou sur devis) et ajuste les tarifs.

## 8. Héberger le site public

Le plus simple avec Cloudflare : **Cloudflare Pages**.

```bash
cd frontend
wrangler pages deploy . --project-name=elan-demenagement
```

Ça te donne une URL `https://elan-demenagement.pages.dev`, et tu peux y attacher ton propre nom de domaine gratuitement depuis le dashboard Cloudflare Pages.

## 9. Mettre le tout sur GitHub (optionnel mais inclus)

Le zip est prêt pour ça : `.gitignore` exclut déjà ce qu'il ne faut jamais committer (`.wrangler/`, `.dev.vars`, `.env`...).

```bash
cd elan-demenagement
git init
git add .
git commit -m "Premier commit"
git branch -M main
git remote add origin https://github.com/<ton-compte>/elan-demenagement.git
git push -u origin main
```

**Important : les secrets (`ADMIN_PASSWORD`, `ADMIN_TOKEN_SECRET`, `RESEND_API_KEY`) ne sont jamais dans le repo.** Ils vivent uniquement côté Cloudflare (posés une fois avec `wrangler secret put`, étape 4). Le `database_id` dans `wrangler.toml`, lui, n'est pas secret — il peut rester dans le repo public sans souci.

**Déploiement automatique à chaque push (déjà configuré)** : le fichier `.github/workflows/deploy.yml` redéploie le Worker et le site Pages à chaque push sur `main`. Pour que ça marche, ajoute deux secrets dans GitHub (Settings → Secrets and variables → Actions) :
- `CLOUDFLARE_API_TOKEN` : crée-le sur [dash.cloudflare.com/profile/api-tokens](https://dash.cloudflare.com/profile/api-tokens) avec le template "Edit Cloudflare Workers" (ajoute aussi la permission Pages si proposée séparément).
- `CLOUDFLARE_ACCOUNT_ID` : visible dans le dashboard Cloudflare, dans la barre latérale droite de n'importe quelle page de ton compte.

Sans ces deux secrets GitHub, le repo reste utile comme sauvegarde/versioning, mais le déploiement automatique ne se lancera pas — tu peux toujours déployer à la main avec les commandes `wrangler` des étapes 5 et 8.

## 10. Calendrier de réservation (Cal.com, gratuit)

Deux réservations sont branchées sur [Cal.com](https://cal.com) (plan gratuit, illimité pour un seul utilisateur) :
- **"Réserver un appel conseil"** (bouton dans le menu et le hero) → un rendez-vous téléphonique avant le devis.
- **Le créneau de déménagement**, directement dans l'étape 5 du simulateur → le client choisit un vrai créneau disponible plutôt que de juste taper une date.

**Mise en place (5 min) :**
1. Crée un compte gratuit sur [cal.com](https://cal.com).
2. Dans "Event Types", crée deux événements avec **exactement** ces identifiants (slugs) :
   - `appel-conseil` (ex. 15 min, visio ou téléphone)
   - `creneau-demenagement` (ex. créneau d'une demi-journée ou journée, à ajuster selon ta réalité terrain)
3. Configure tes disponibilités réelles dans Cal.com (Availability) — c'est ce calendrier qui empêche les doubles réservations.
4. Ouvre `frontend/index.html`, cherche :
   ```js
   const CAL_USERNAME = "TON-COMPTE-CALCOM";
   ```
   Remplace par ton nom d'utilisateur Cal.com (visible dans l'URL de ton profil, ex. `cal.com/emreh-elan`).

Le créneau choisi par le client est automatiquement récupéré et envoyé avec le reste de sa demande de devis (visible dans l'espace pro, colonne "date souhaitée").

**Pour aller plus loin (optionnel) :** Cal.com propose des webhooks — tu peux en configurer un vers ton Worker plus tard si tu veux que chaque réservation crée aussi une ligne directement dans ta base D1, sans dépendre uniquement du formulaire de devis. Dis-le-moi si tu veux qu'on le mette en place.

## Limites à connaître (tout est gratuit, mais...)

- **Cloudflare Workers** (plan gratuit) : 100 000 requêtes/jour — largement suffisant pour un site de déménageur.
- **D1** (plan gratuit) : 5 Go de stockage, 5 millions de lectures/jour — très large marge.
- **Resend** (plan gratuit) : 3 000 emails/mois, 1 domaine vérifié.
- Le code d'accès pro se change uniquement avec `wrangler secret put ADMIN_PASSWORD` (pas depuis le site) — c'est volontaire, pour rester simple et sécurisé sans système de comptes complet.
- Le prix final affiché au client est toujours recalculé **côté serveur** à partir des tarifs enregistrés — un visiteur ne peut pas trafiquer le prix en modifiant le code du site.
